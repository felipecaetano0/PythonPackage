def evaluate(expression):
    """
    Testable function
    :param expression:
    :return:
    """
    return eval(expression)


def evaluate_expression(expression):
    print(evaluate(expression))
